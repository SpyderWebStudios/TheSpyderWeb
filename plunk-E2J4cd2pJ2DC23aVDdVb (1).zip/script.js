// Code goes here
(function(window, google){
    //map options
    var options = {
      centre: {
        lat: 37.791350,
        lng: -122.435883
      },
      zoom: 10,
      disableDefaulUi : true,
      scrollwhell: true,
      myMapId: google.maps.MapTypeId.ROADMAP
      
      
    },
    element = document.getElementById('map-canvas'),
    //map
map = new google.maps.Map(element, options);

}(window, google));
